# To run:
- Install deps: ```npm i```
- Run core.js: ```node core.js```