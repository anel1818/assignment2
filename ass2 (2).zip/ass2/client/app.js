const condition = document.getElementById("condition");
const city = document.getElementById("city");
const country = document.getElementById("country");
const mainText = document.getElementById("main");
const description = document.getElementById("description");
const temp = document.getElementById("temp");
const feelsLike = document.getElementById("feels-like");
const pressure = document.getElementById("pressure");
const humidity = document.getElementById("humidity");
const windSpeed = document.getElementById("wind-speed");
const rainVolume = document.getElementById("rain-volume");
const cityInput = document.getElementById("city-input");

const DEFAULT_CITY = "Astana, Kazakhstan";
const API_KEY = "195e4a42b47f0c72e2968df26ac64d2a";
const BASE_URL = `https://api.openweathermap.org/data/2.5/weather?appid=${API_KEY}`;
const ICON_URL = "http://openweathermap.org/img/wn/";
const OPUV_API_KEY = "openuv-2owted0rls0a88gd-io"; 
const OPUV_BASE_URL = "https://api.openuv.io/api/v1/uv";
 

const API_NINJAS_KEY = "cJv0X2CNINFw5+CGvbi+yA==ZkirszxZQGtIL9ke"; 
const WEATHERBIT_API_KEY = "e5f35d214c36443680b69d0c92deec60"; 
const WEATHERBIT_BASE_URL = "https://api.weatherbit.io/v2.0/current/airquality";

let map;
let marker;
 
window.onload = function () {
    navigator.geolocation.getCurrentPosition(
        getWeatherWithCoords,
        handleGeolocationError
    );
    initMap();
    getWeatherData(DEFAULT_CITY);
    cityInput.addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            const enteredCity = cityInput.value.trim();
            if (enteredCity) {
                getWeatherData(enteredCity);
                e.target.value = "";
            } else {
                alert("Please Enter a Valid City Name");
            }
        }
    });
};
 
async function getWeatherData(cityName) {
    try {
        const response = await axios.get(`${BASE_URL}&q=${cityName}`);
        const weather = response.data;
        setWeather(weather);
        getLocalTime(cityName); 
    } catch (error) {
        console.error("Error fetching data:", error);
        alert("City not found or an error occurred");
    }
}
 
function setWeather(weatherData) {
    condition.src = `${ICON_URL}${weatherData.weather[0].icon}.png`;
    city.innerHTML = weatherData.name;
    country.innerHTML = weatherData.sys.country;
    mainText.innerHTML = weatherData.weather[0].main;
    description.innerHTML = weatherData.weather[0].description;
    temp.innerHTML = kelvinToCelsius(weatherData.main.temp);
    feelsLike.innerHTML = kelvinToCelsius(weatherData.main.feels_like);
    pressure.innerHTML = weatherData.main.pressure;
    humidity.innerHTML = weatherData.main.humidity;
    windSpeed.innerHTML = weatherData.wind.speed;
    
    rainVolume.innerHTML = weatherData.rain ? weatherData.rain['1h'] : '0';
    updateMap(weatherData.coord.lat, weatherData.coord.lon);
    getUVIndex(weatherData.coord.lat, weatherData.coord.lon);
}
 
function kelvinToCelsius(kelvin) {
    return (kelvin - 273.15).toFixed(2);
}
 
function getWeatherWithCoords(position) {
    const { latitude, longitude } = position.coords;
    updateMap(latitude, longitude);
    getWeatherData(`${latitude},${longitude}`);
}
 
function handleGeolocationError(error) {
    console.error(error);
    alert("Geolocation error. Defaulting to a predefined city.");
    getWeatherData(DEFAULT_CITY);
}

// Function to initialize the map
function initMap(latitude = 51.1655, longitude = 71.4272) {
    let mapOptions = {
        zoom: 13,
        center: new google.maps.LatLng(latitude, longitude),
    };
    map = new google.maps.Map(document.getElementById('map'), mapOptions);
    marker = new google.maps.Marker({
        position: mapOptions.center,
        map: map,
        title: 'Weather Location',
    });
}
 
// Function to update the map location
function updateMap(latitude, longitude) {
    let newLocation = new google.maps.LatLng(latitude, longitude);
    map.setCenter(newLocation);
    marker.setPosition(newLocation);
}
 
async function getLocalTime(cityName) {
    try {
        const response = await axios.get(`https://api.api-ninjas.com/v1/timezone?city=${cityName}`, {
            headers: { 'X-Api-Key': API_NINJAS_KEY }
        });
        const localTimeData = response.data;
        displayLocalTime(localTimeData.timezone); 
    } catch (error) {
        console.error("Error fetching local time:", error);
        displayLocalTime("Local time not available");
    }
}
 
function displayLocalTime(time) {
   document.getElementById("local-time").innerText = time;
}

 
async function getUVIndex(latitude, longitude) {
    try {
        const response = await axios.get(OPUV_BASE_URL, {
            params: { lat: latitude, lng: longitude },
            headers: { 'x-access-token': OPUV_API_KEY }
        });
        const uvData = response.data;
        displayUVIndex(uvData.result.uv);
    } catch (error) {
        console.error("Error fetching UV Index data:", error);
        displayUVIndex("UV Index data not available");
    }
}
 
function displayUVIndex(uvIndex) {
    document.getElementById("uv-index").innerText = `UV Index: ${uvIndex}`;
}
 
